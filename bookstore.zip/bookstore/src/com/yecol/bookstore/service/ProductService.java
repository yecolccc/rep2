package com.yecol.bookstore.service;

import java.sql.SQLException;
import java.util.List;

import com.yecol.bookstore.dao.ProductDao;
import com.yecol.bookstore.model.PageResult;
import com.yecol.bookstore.model.Product;

public class ProductService {
	
	ProductDao productDao = new ProductDao();
	
	/**
	 * 查询分类的bean对象
	 * @param category
	 * @param page 当前页
	 * @return
	 */
	public PageResult<Product> findBooks(String category, int page) {
		PageResult<Product> pr = null;
		try {
			//创建模型
			pr = new PageResult<Product>();
			//设置总记录数
			long totalCount = productDao.count(category);
			pr.setTotalCount(totalCount);
			
			//查询每页显示数量 给了默认值为4
			int pageSize = pr.getPageSize();
			
			//设置总页数
			int totalPage = (int) (totalCount%pageSize == 0 ? totalCount/pageSize : totalCount/pageSize + 1);
			pr.setTotalPage(totalPage);
			
			//设置当前页的list
			List<Product> list = productDao.findBooks(category, page, pageSize);
			pr.setList(list);
			
			//设置当前页
			pr.setCurrentPage(page);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return pr;
	}
	
	public Product findBook(String id) {
		try {
			return productDao.findBook(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

}
