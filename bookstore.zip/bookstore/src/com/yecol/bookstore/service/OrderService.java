package com.yecol.bookstore.service;

import com.yecol.bookstore.model.Order;
import com.yecol.bookstore.model.OrderItem;
import com.yecol.bookstore.utils.ManagerThreadLocal;

import java.sql.SQLException;
import java.util.List;

import com.yecol.bookstore.dao.OrderDao;
import com.yecol.bookstore.dao.OrderItemsDao;
import com.yecol.bookstore.dao.ProductDao;

/**
 * 订单业务层
 * @author yecol
 *
 */
public class OrderService {

	private OrderDao orderDao = new OrderDao();
	private OrderItemsDao itemDao = new OrderItemsDao();
	private ProductDao productDao = new ProductDao();
	
	/**
	 * 创建订单
	 * @param order
	 */
	public void createOrder(Order order) {
		try {
			//开启事务
			ManagerThreadLocal.beginTransaction();
			orderDao.add(order);
			itemDao.add(order.getItems());
			for(OrderItem item : order.getItems()) {
				productDao.updatePnum(item.getProduct().getId(), item.getBuynum());
			}
			//提交事务
			ManagerThreadLocal.commitTransaction();
		} catch (Exception e) {
			e.printStackTrace();
			//回滚事务
			ManagerThreadLocal.rollbackTransaction();
		}
	}
	
	/**
	 * 根据用户id查找他的订单
	 * @param userId
	 * @return
	 */
	public List<Order> findOrderById(String userId) {
		try {
			return orderDao.findOrderById(userId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据订单id查询订单
	 * @param orderId
	 * @return
	 */
	public Order findOrderByOrderId(String orderId) {
		try {
			Order order = orderDao.findOrderByOrderId(orderId);
			return order;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据订单id修改支付状态
	 * @param id
	 * @throws SQLException
	 */
	public void uptateStateById(String id) {
		try {
			orderDao.uptateStateById(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 根据id和收件人查询订单信息
	 * @param id
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public List<Order> findByIdOrName(String id, String name) {
		try {
			return orderDao.findByIdOrName(id, name);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
