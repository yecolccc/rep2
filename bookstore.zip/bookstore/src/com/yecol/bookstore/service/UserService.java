package com.yecol.bookstore.service;

import java.sql.SQLException;

import com.yecol.bookstore.dao.UserDao;
import com.yecol.bookstore.exception.UserException;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.utils.SendJMail;

/**
 * user业务层
 * @author yecol
 *
 */
public class UserService {

	UserDao userDao = new UserDao();
	
	/**
	 * 注册
	 * @param user
	 */
	public void regist(User user)throws UserException {
		try {
			userDao.addUser(user);
			
			String link = "http://localhost:8080/bookstore/active?activeCode=" + user.getActiveCode();
			
			String html = " <a href=\""+link+"\">" + user.getUsername() + " 欢迎您注册网上书城，请点击激活</a>";
			System.out.println(html);
			//发送激活邮件
			SendJMail.sendMail(user.getEmail(), html);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("注册失败，用户名重复");
		}
	}
	
	/**
	 * 激活用户
	 * @param activeCode
	 * @throws UserException
	 */
	public void activeUser(String activeCode) throws UserException {
		User user = null;
		try {
			//1.查询用户是否存在
			user = userDao.findUserByActiveCode(activeCode);
			
		} catch (SQLException e) {
			throw new UserException("激活失败");
		}
		
		if(user == null) {
			throw new UserException("非法激活，用户不存在");
		}
		if(user != null && user.getState() == 1) {
			throw new UserException("激活无效，用户已经激活...");
		}
		
		//2.激活用户
		try {
			userDao.updateState(activeCode);
		} catch (SQLException e) {
			throw new UserException("激活失败");
		}
	}
	
	/**
	 * 登录
	 * @param username
	 * @param password
	 * @return
	 * @throws UserException
	 */
	public User login(String username, String password) throws UserException {
		try {
			//1.查询
			User user = userDao.findUserByUsernameAndPassword(username, password);
			//2.判断
			if(user == null) {
				throw new UserException("用户名或密码不正确");
			}
			
			if(user.getState() == 0) {
				throw new UserException("用户尚未激活");
			}
			
			//3.返回
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("登录失败");
		}
	}
	
	/**
	 * 通过id查找
	 * @param id
	 * @return
	 * @throws UserException
	 */
	public User findUserById(String id) throws UserException {
		try {
			//1.查询
			User user = userDao.findUserById(id);
			//2.判断
			if(user == null) {
				throw new UserException("id不存在");
			}
			
			//3.返回
			return user;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("未知错误");
		}
	}
	
	public void modifyUserInfo(User user) throws UserException {
		try {
			userDao.updateUser(user);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new UserException("未知错误");
		}
	}
	
}
