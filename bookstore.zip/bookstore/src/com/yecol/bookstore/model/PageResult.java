package com.yecol.bookstore.model;

import java.util.List;

/**
 * 分页模型
 * @author yecol
 *
 */
public class PageResult<T> {
	
	List<T> list;
	int totalPage; //总页数;	算出来的
	long totalCount; //总条数;	dao查出来的
	int currentPage; //当前页;	传进来的
	int pageSize = 4; //页面显示条数;	传进来的
	public List<T> getList() {
		return list;
	}
	public void setList(List<T> list) {
		this.list = list;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	@Override
	public String toString() {
		return "PageResult [totalPage=" + totalPage + ", totalCount=" + totalCount + ", currentPage=" + currentPage
				+ ", pageSize=" + pageSize + "]";
	}

	
}
