package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.exception.UserException;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.service.UserService;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = -6735731765838400640L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("content-type", "text/html;charset=utf-8");
		
		//1.获取请求参数
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		
		//2.调用Service
		UserService us = new UserService();
		try {
			User user = us.login(username, password);
			//把user保存在session中
			//管理员不用存在session中
			req.getSession().setAttribute("user", user);
			
			//判断是否为管理员
			if("管理员".equals(user.getRole())) {
				//清楚这个session
				req.getSession().removeAttribute("user");
				//进入后台界面
				resp.sendRedirect(req.getContextPath() + "/admin/login/home.jsp");
			} else {
				//登陆成功 回到index.jsp
//				req.getRequestDispatcher("/index.jsp").forward(req, resp); 不用转发 避免刷新时重复提交
				resp.sendRedirect(req.getContextPath() + "/index.jsp");
			}
			
		} catch (UserException e) {
			e.printStackTrace();
			//登录失败 回到登陆页面
			req.setAttribute("login_msg", e.getMessage());
			req.getRequestDispatcher("/login.jsp").forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
	

}
