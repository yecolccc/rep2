package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.yecol.bookstore.exception.UserException;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.service.UserService;

@WebServlet("/modifyUserInfo")
public class ModifyUserInfoServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("content-type", "text/html;charset=utf-8");
		
		//1.获取表单的参数
		User user = new User();
		try {
			BeanUtils.populate(user, req.getParameterMap());
//			System.out.println(user);
			
			//2.修改
			UserService us = new UserService();
			us.modifyUserInfo(user);
			
			//3.跳转
			resp.sendRedirect(req.getContextPath() + "/modifyUserInfoSuccess.jsp");
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (UserException e) {
			e.printStackTrace();
			resp.getWriter().write(e.getMessage());
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
