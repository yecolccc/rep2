package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.User;

@WebServlet("/settleAccount")
public class SettleAccountServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//判断当前浏览器是否登录
		User user = (User) req.getSession().getAttribute("user");
		if(user != null) {
			//已经登录 进入订单页面
			resp.sendRedirect(req.getContextPath() + "/order.jsp");
		} else {
			resp.sendRedirect(req.getContextPath() + "/login.jsp");
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
