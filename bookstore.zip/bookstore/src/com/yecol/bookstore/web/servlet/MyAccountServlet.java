package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.User;


@WebServlet("/myaccount")
public class MyAccountServlet extends HttpServlet {

	private static final long serialVersionUID = -1611086769394813545L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("content-type", "text/html;charset=utf-8");
		
		User user = (User) req.getSession().getAttribute("user");
		if(user == null) {
			//如果未登录就进入login.jsp
			resp.sendRedirect(req.getContextPath() + "/login.jsp");
		} else {
			//如果登录就进myAccount.jsp
			resp.sendRedirect(req.getContextPath() + "/myAccount.jsp");
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
}
