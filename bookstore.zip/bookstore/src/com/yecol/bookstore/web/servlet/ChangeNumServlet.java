package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.service.ProductService;

@WebServlet("/changeNum")
public class ChangeNumServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//获取参数
		String id = req.getParameter("id");
		String num = req.getParameter("num");
		
		//根据id获取商品
		ProductService ps = new ProductService();
		Product book = ps.findBook(id);
		
		//通过商品更新商品数据
		@SuppressWarnings("unchecked")
		Map<Product, Integer> cart = (Map<Product, Integer>) req.getSession().getAttribute("cart");
		
		//替换
		if(cart.containsKey(book)) {
			if("0".equals(num)) {
				cart.remove(book);
			} else {
				cart.put(book, Integer.parseInt(num));
			}
		}
		
		//重新保存在session中
		req.getSession().setAttribute("cart", cart);
		//回到购物车页面
		resp.sendRedirect(req.getContextPath() + "/cart.jsp");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
