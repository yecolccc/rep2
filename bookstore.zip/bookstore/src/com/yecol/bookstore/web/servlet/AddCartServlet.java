package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
//import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.service.ProductService;

/**
 * 添加购物车的Servlet
 * @author yecol
 *
 */
@WebServlet("/addCart")
public class AddCartServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//1.获取数据
		String id = req.getParameter("id");
		
		//2.通过id查询对应的商品
		ProductService ps = new ProductService();
		Product p = ps.findBook(id);
		
		//判断库存
		if(p.getPnum() <= 0) {
			resp.getWriter().write("该书暂无库存，请联系管理员进货");
			return;
		}
		
		//3.把商品放到购物车的Map中
		//3.1先从session中获取购物车的数据[cart]
		@SuppressWarnings("unchecked")
		Map<Product, Integer> cart = (Map<Product, Integer>) req.getSession().getAttribute("cart");
		//3.2没有购物车数据就创建一个对象
		if(cart == null) {
			cart = new HashMap<Product, Integer>();
			cart.put(p, 1);
		} else {
			//3.3判断Map中存在当前想购买的商品
			if(cart.containsKey(p)) {
				cart.put(p, cart.get(p) + 1);
			} else {
				cart.put(p, 1);
			}
		}
		
		//4.打印购物车数据
		/*for(Entry<Product, Integer> entry : cart.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}*/
		
		//5.存入session
		req.getSession().setAttribute("cart", cart);
		
		String s1 = "<a href=\""+ req.getContextPath() +"\">继续购物</a>";
		String s2 = "<a href=\""+ req.getContextPath() +"/cart.jsp\">查看购物车</a>";
		PrintWriter writer = resp.getWriter();
		writer.write(s1);
		writer.write("&nbsp&nbsp");
		writer.write(s2);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
