package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.PageResult;
import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.service.ProductService;

@WebServlet("/showProductByPage")
public class ShowProductByPageServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//1.获取参数
		String category = req.getParameter("category");
		String pageStr = req.getParameter("page");
		int page = 1;	//默认当前页为1
		if(pageStr != null && !"".equals(pageStr)) {
			page = Integer.parseInt(pageStr);
		}
		
		//2.调用service查询
		ProductService ps = new ProductService();
		PageResult<Product> pageResult = ps.findBooks(category, page);
		
		//3.存在request中
		req.setAttribute("pageResult", pageResult);
		req.setAttribute("category", category);
		
		//4.跳转页面
		req.getRequestDispatcher("/product_list.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
