package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.yecol.bookstore.exception.UserException;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.service.UserService;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 5545182224363095748L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("content-type", "text/html;charset=utf-8");
		
		//检验验证码
		String checkcode_client = req.getParameter("checkcode");//根据name的值传的
		String checkcode_session = (String) req.getSession().getAttribute("checkcode_session");
		if(!checkcode_client.equals(checkcode_session)) {
			//不一致 返回注册页面
			req.setAttribute("checkcode_error", "验证码输入错误");
			req.getRequestDispatcher("/register.jsp").forward(req, resp);
			return;
		}
		
		//1.将参数转成Bean
		User user = new User();
		try {
			BeanUtils.populate(user, req.getParameterMap());
			
			//给无数据的属性赋值
			user.setActiveCode(UUID.randomUUID().toString());
			user.setRole("普通用户");
			user.setRegistTime(new Date());
//			System.out.println(user);
			
			//2.注册
			UserService userService = new UserService();
			userService.regist(user);
			
			//3.返回结果
			//3.1成功-进入登录界面
			req.getRequestDispatcher("/registersuccess.jsp").forward(req, resp);
		} catch (UserException e) {
			e.printStackTrace();
			// 3.2失败-回到注册页面
			req.setAttribute("register_error", e.getMessage());
			req.getRequestDispatcher("/register.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
	

}
