package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.exception.UserException;
import com.yecol.bookstore.service.UserService;

@WebServlet("/active")
public class ActiveServlet extends HttpServlet {
	
	private static final long serialVersionUID = 826216864651220587L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setHeader("content-type", "text/html;charset=utf-8");
		
		 //1.获取参数
		String activeCode = req.getParameter("activeCode");
		//2.激活
		UserService us = new UserService();
		try {
			us.activeUser(activeCode);
			resp.getWriter().write("激活成功");
		} catch (UserException e) {
			e.printStackTrace();
			resp.getWriter().write(e.getMessage());
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
