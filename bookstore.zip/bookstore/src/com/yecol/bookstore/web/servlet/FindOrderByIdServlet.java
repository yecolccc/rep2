package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.Order;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.service.OrderService;

/**
 * 通过用户的id查找订单
 * @author yecol
 *
 */
@WebServlet("/findOrderById")
public class FindOrderByIdServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//获取参数
		User user = (User) req.getSession().getAttribute("user");
		if(user == null) {
			resp.getWriter().write("非法访问");
			return;
		}
		OrderService os = new OrderService();
		List<Order> orders = os.findOrderById(user.getId() + "");
		//存入request中
		req.setAttribute("orders", orders);
		req.getRequestDispatcher("/orderlist.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
