package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.Order;
import com.yecol.bookstore.service.OrderService;

/**
 * 给管理员添加订单数据
 * @author yecol
 *
 */
@WebServlet("/addOrderData")
public class AddOrderDataServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//获取提交的参数
		String id = req.getParameter("id");
		String name = req.getParameter("receiverName");
		//从数据库中获取订单数据
		OrderService os = new OrderService();
		List<Order> orders = os.findByIdOrName(id, name);
		//存入request域中
		req.setAttribute("orders", orders);
		//转发数据
		req.getRequestDispatcher("/admin/orders/list.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
