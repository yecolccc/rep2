package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.exception.UserException;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.service.UserService;


@WebServlet("/findUserById")
public class FindUserByIdServlet extends HttpServlet {

	private static final long serialVersionUID = 7437314201253515565L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("content-type", "text/html;charset=utf-8");
		
		//1.获取参数
		String id = req.getParameter("id");
		//2.在数据库中查
		UserService us = new UserService();
		User user = null;
		try {
			user = us.findUserById(id);
		} catch (UserException e) {
			e.printStackTrace();
		}
		//3.放在request域中
		req.setAttribute("u", user);
		
		//4.转发到modifyuserinfo.jsp
		req.getRequestDispatcher("/modifyuserinfo.jsp").forward(req, resp);
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
}
