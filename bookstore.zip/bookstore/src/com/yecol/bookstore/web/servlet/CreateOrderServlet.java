package com.yecol.bookstore.web.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import com.yecol.bookstore.model.Order;
import com.yecol.bookstore.model.OrderItem;
import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.service.OrderService;

@WebServlet("/createOrder")
public class CreateOrderServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//获取用户
		User user = (User) req.getSession().getAttribute("user");
		if(user == null) {
			resp.getWriter().write("非法访问");
			return;
		}
		
		//获取购物车
		@SuppressWarnings("unchecked")
		Map<Product, Integer> cart = (Map<Product, Integer>) req.getSession().getAttribute("cart");
		if(cart == null || cart.size() == 0) {
			resp.getWriter().write("当前购物车无商品");
			return;
		}
		
		Order order = new Order();
		try {
			BeanUtils.populate(order, req.getParameterMap());
			//补充数据
			order.setId(UUID.randomUUID().toString());
			order.setOrdertime(new Date());
			order.setUser(user);
			
			//定义商品总价格
			double totalPrice = 0;
			
			//封装订单详情OrderItem[一个订单有多个商品]
			List<OrderItem> items = new ArrayList<OrderItem>();
			//遍历购物车
			for(Entry<Product, Integer> entry : cart.entrySet()) {
				OrderItem orderItem = new OrderItem();
				orderItem.setBuynum(entry.getValue());
				orderItem.setProduct(entry.getKey());
				orderItem.setOrder(order);
				items.add(orderItem);
				
				//计算总价格
				totalPrice += entry.getKey().getPrice() * entry.getValue();
			}
			
			//设置order中的List 为了简化service的操作
			order.setItems(items);
			
			//设置总价格
			order.setMoney(totalPrice);
			
			//插入数据库
			OrderService orderService = new OrderService();
			orderService.createOrder(order);
			
			//下单成功移除购物车的数据
			req.getSession().removeAttribute("cart");
			
			//提示下单成功
			resp.getWriter().write("<a href=\""+req.getContextPath()+"/index.jsp\">下单成功点击返回首页</a>");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
