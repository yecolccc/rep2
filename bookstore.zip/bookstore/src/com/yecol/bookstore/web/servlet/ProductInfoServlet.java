package com.yecol.bookstore.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.service.ProductService;

/**
 * 显示商品详情的Servlet
 * @author yecol
 *
 */
@WebServlet("/productInfo")
public class ProductInfoServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//1.获取参数
		String id = req.getParameter("id");
		
		//2.调用Service查询
		ProductService ps = new ProductService();
		Product product = ps.findBook(id);
		
		//3.存入request域
		req.setAttribute("product", product);
		
		//4.跳转页面
		req.getRequestDispatcher("/product_info.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}
