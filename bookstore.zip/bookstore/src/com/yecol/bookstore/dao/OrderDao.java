package com.yecol.bookstore.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.yecol.bookstore.model.Order;
import com.yecol.bookstore.model.OrderItem;
import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.model.User;
import com.yecol.bookstore.utils.C3P0Uitls;
import com.yecol.bookstore.utils.ManagerThreadLocal;

/**
 * 订单持久层
 * @author yecol
 *
 */
public class OrderDao {

	/**
	 * 创建订单
	 * @param order
	 * @throws SQLException
	 */
	public void add(Order order) throws SQLException {
		//创建sql
		String sql = "insert into orders values(?,?,?,?,?,?,?,?)";
		//添加参数
		List<Object> params = new ArrayList<Object>();
		params.add(order.getId());
		params.add(order.getMoney());
		params.add(order.getReceiverAddress());
		params.add(order.getReceiverName());
		params.add(order.getReceiverPhone());
		params.add(order.getPaystate());
		params.add(order.getOrdertime());
		params.add(order.getUser().getId());
		//创建qr
//		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		//执行sql
//		qr.update(sql,params.toArray());
		
		//改进
		QueryRunner qr = new QueryRunner();
		qr.update(ManagerThreadLocal.getConnection(),sql,params.toArray());
	}
	
	/**
	 * 通过用户的id查找订单
	 * @param userId
	 * @return
	 * @throws SQLException 
	 */
	public List<Order> findOrderById(String userId) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from orders where user_id = ?";
		return qr.query(sql, new BeanListHandler<Order>(Order.class),userId);
	}
	
	/**
	 * 根据订单id查询订单 并封装数据
	 * @param orderId
	 * @return
	 * @throws SQLException
	 */
	public Order findOrderByOrderId(String orderId) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from orders where id = ?";
		//根据订单的id查询订单
		Order order = qr.query(sql, new BeanHandler<Order>(Order.class),orderId);
		String sql2 = "SELECT oi.*,p.name,p.price FROM orderItem oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
		//自行封装数据
		List<OrderItem> mitems = qr.query(sql2, new ResultSetHandler<List<OrderItem>>() {

			@Override
			public List<OrderItem> handle(ResultSet rs) throws SQLException {
				//1.创建集合对象
				List<OrderItem> items =new ArrayList<OrderItem>();
				//2.遍历
				while(rs.next()) {
					OrderItem item = new OrderItem();
					item.setBuynum(rs.getInt("buynum"));
					//创建product对象
					Product product = new Product();
					product.setId(rs.getInt("product_id"));
					product.setName(rs.getString(4));
					product.setPrice(rs.getDouble(5));
					//将product存在item中
					item.setProduct(product);
					//将item存放在集合中
					items.add(item);
				}
				return items;
			}
			
		},orderId);
		//在order中添加orderItems
		order.setItems(mitems);
		
		return order;
	}
	
	/**
	 * 根据订单id修改支付状态
	 * @param id
	 * @throws SQLException
	 */
	public void uptateStateById(String id) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "update orders set paystate = 1";
		qr.update(sql);
	}
	
	/**
	 * 根据id和收件人查询订单信息
	 * @param id
	 * @param name
	 * @return
	 * @throws SQLException
	 */
	public List<Order> findByIdOrName(String id, String name) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from orders where 1 = 1";
		List<Object> params = new ArrayList<Object>();
		if(id != null && !"".equals(id)) {
			sql += " and id = ? ";
			params.add(id);
		}
		
		if(name != null && !"".equals(name)) {
			sql += " and receiverName like ? ";
			params.add("%" + name + "%");
		}
		
		//查询 实现自定义封装 为了封装一个userId
		List<Order> orders = qr.query(sql, new ResultSetHandler<List<Order>>() {

			@Override
			public List<Order> handle(ResultSet rs) throws SQLException {
				//创建集合对象
				List<Order> list = new ArrayList<Order>();
				//遍历resultSet
				while(rs.next()) {
					Order o = new Order();
					o.setId(rs.getString(1));
					o.setMoney(rs.getDouble(2));
					o.setReceiverAddress(rs.getString(3));
					o.setReceiverName(rs.getString(4));
					o.setReceiverPhone(rs.getString(5));
					o.setPaystate(rs.getInt(6));
					o.setOrdertime(rs.getDate(7));
					User user = new User();
					user.setId(rs.getInt(8));
					o.setUser(user);
					list.add(o);
				}
				return list;
			}
			
		},params.toArray());
		return orders;
	}
	
	public static void main(String[] args) throws SQLException {
		OrderDao dao = new OrderDao();
		/*Order order = dao.findOrderByOrderId("15840ced-a497-4c76-b34c-d3d9fb610fc5");
		System.out.println(order);
		System.out.println(order.getItems());*/
		List<Order> orders = dao.findByIdOrName("15840ced-a497-4c76-b34c-d3d9fb610fc5", "");
		for (Order order : orders) {
			System.out.println(order);
			System.out.println(order.getItems());
		}
	}
	
}
