package com.yecol.bookstore.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.yecol.bookstore.model.User;
import com.yecol.bookstore.utils.C3P0Uitls;

/**
 * user持久层
 * @author yecol
 *
 */
public class UserDao {
	
	public void addUser(User user) throws SQLException {
		//1.创建QueryRunner
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		//2.定义sql
		String sql = "insert into user(username,password,gender,email,telephone,introduce,activeCode,state,role,registTime)";
		sql += " values(?,?,?,?,?,?,?,?,?,?)";
		//3.添加数据
		List<Object> list = new ArrayList<Object>();
		list.add(user.getUsername());
		list.add(user.getPassword());
		list.add(user.getGender());
		list.add(user.getEmail());
		list.add(user.getTelephone());
		list.add(user.getIntroduce());
		list.add(user.getActiveCode());
		list.add(user.getState());
		list.add(user.getRole());
		list.add(user.getRegistTime());
		
		//4.ִ执行sql
		qr.update(sql, list.toArray());
	}	
	
	/**
	 * 通过激活码查找用户
	 * @param activeCode
	 * @return
	 * @throws SQLException 
	 */
	public User findUserByActiveCode(String activeCode) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from user where activeCode = ?";
		
		return qr.query(sql, new BeanHandler<User>(User.class),activeCode);
	}
	
	/**
	 * 根据激活码修改用户的状态
	 * @param activeCode
	 * @throws SQLException
	 */
	public void updateState(String activeCode) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "update user set state = 1 where activeCode = ?";
		
		qr.update(sql,activeCode);
	}
	
	/**
	 * 通过用户名和密码查找用户
	 * @param username
	 * @param password
	 * @return
	 * @throws SQLException
	 */
	public User findUserByUsernameAndPassword(String username, String password) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from user where username = ? and password = ?";
		return qr.query(sql, new BeanHandler<User>(User.class),username,password);
	}
	
	/**
	 * 通过id查找用户
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public User findUserById(String id) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from user where id = ?";
		return qr.query(sql, new BeanHandler<User>(User.class),id);
	}
	
	/**
	 * 更改用户信息
	 * @param user
	 * @throws SQLException
	 */
	public void updateUser(User user) throws SQLException {
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "update user set password = ?,gender = ?,telephone = ? where id = ?";
		
		qr.update(sql,user.getPassword(),user.getGender(),user.getTelephone(),user.getId());
	}
	
}
