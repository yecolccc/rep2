package com.yecol.bookstore.dao;

import java.sql.SQLException;
//import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;

import com.yecol.bookstore.model.OrderItem;
//import com.yecol.bookstore.utils.C3P0Uitls;
import com.yecol.bookstore.utils.ManagerThreadLocal;

/**
 * 订单详情持久层
 * @author yecol
 *
 */
public class OrderItemsDao {

	/**
	 * 添加订单详情
	 * @param items
	 * @throws SQLException 
	 */
	public void add(List<OrderItem> items) throws SQLException {
		String sql = "insert into orderItem(order_id,product_id,buynum) values (?,?,?)";
		QueryRunner qr = new QueryRunner();
		/*for (OrderItem item : items) {
			//获取参数
			List<Object> params = new ArrayList<Object>();
			params.add(item.getOrder().getId());
			params.add(item.getProduct().getId());
			params.add(item.getBuynum());
			qr.update(sql,params.toArray());
		}*/
		
		//优化
		//创建二维数组
		Object[][] params = new Object[items.size()][];
		for(int i = 0; i < items.size(); i++) {
			OrderItem item = items.get(i);
			params[i] = new Object[] {item.getOrder().getId(),item.getProduct().getId(),item.getBuynum()};
		}
		
		//批处理执行sql语句
		qr.batch(ManagerThreadLocal.getConnection(),sql, params);
	}
	
}
