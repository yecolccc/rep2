package com.yecol.bookstore.dao;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.yecol.bookstore.model.Product;
import com.yecol.bookstore.utils.C3P0Uitls;
import com.yecol.bookstore.utils.ManagerThreadLocal;

public class ProductDao {
	
	/**
	 * 根据类型查询总条数
	 * @param category
	 * @return
	 * @throws SQLException
	 */
	public long count(String category) throws SQLException {
		//定义记录数为0
		long count = 0;
		//创建qr
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		//定义sql
		String sql = "select count(*) from products where 1=1 ";
		//判断category是否有值
		if(category != null && !"".equals(category)) {
			sql += " and category = ?";
			count = (long) qr.query(sql, new ScalarHandler(),category);
		} else {
			count = (long) qr.query(sql, new ScalarHandler());
		}
		//返回结果
		return count;
	}
	
	/**
	 * 查询当前页的数据
	 * @param category	种类
	 * @param page	当前页
	 * @param pageSize	每页的数据
	 * @return
	 * @throws SQLException 
	 */
	public List<Product> findBooks(String category, int page, int pageSize) throws SQLException {
		//创建qr
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		//定义sql
		String sql = "select * from products where 1=1 ";
		
		//定义一个传参数的集合
		List<Object> params = new ArrayList<Object>();
		
		//判断category是否有值
		if(category != null && !"".equals(category)) {
			sql += " and category = ?";
			params.add(category);
		}
		
		int start =(page-1)*pageSize;
		int length = pageSize;
		params.add(start);
		params.add(length);
		sql += " limit ?,?";
		
		//返回结果
		return qr.query(sql, new BeanListHandler<Product>(Product.class),params.toArray());
	}
	
	/**
	 * 通过id查找商品
	 * @param id
	 * @return
	 * @throws SQLException
	 */
	public Product findBook(String id) throws SQLException {
		//创建qr
		QueryRunner qr = new QueryRunner(C3P0Uitls.getDataSource());
		String sql = "select * from products where id = ?";
		return qr.query(sql, new BeanHandler<Product>(Product.class),id);
	}
	
	/**
	 * 修改库存
	 * @param id
	 * @param num
	 * @throws SQLException
	 */
	public void updatePnum(int id, int num) throws SQLException {
		String sql = "update products set pnum = pnum - ? where id = ?";
		QueryRunner qr = new QueryRunner();
		qr.update(ManagerThreadLocal.getConnection(),sql,num,id);
	}
	
	
}
